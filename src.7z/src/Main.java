import java.text.SimpleDateFormat;
import java.util.HashMap;

import Librerie.ManageDb;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args) throws SQLException {

		ManageDb shool_DB = new ManageDb();
		boolean dbConnected = shool_DB.Connect("localhost", 3306, "school_db", "school_server", "agata");
		System.out.println(dbConnected);
		ResultSet allClerks = shool_DB.readInDb("SELECT * FROM clerks");
		System.out.println(allClerks);
		boolean insertResult = shool_DB.writeInDB("INSERT INTO ");
		
		
	}

}